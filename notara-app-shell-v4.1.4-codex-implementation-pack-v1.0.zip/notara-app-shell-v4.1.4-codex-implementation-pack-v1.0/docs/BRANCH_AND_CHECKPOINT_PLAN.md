# Branch and Checkpoint Plan — App Shell V4.1.4

## 1. Branch strategy

Gunakan satu branch:

```text
feat/app-shell-v4-1-4-integration
```

Branch berasal dari base branch terbaru yang telah diverifikasi. Jangan membuat branch terpisah untuk setiap checkpoint. Setiap checkpoint menghasilkan satu commit kecil dan dapat direview.

Branch ini **bukan branch mock tanpa backend**. UI baru harus memakai backend dan contract existing tanpa mengubahnya. Larangan utamanya adalah menambah capability backend baru.

## 2. Git safety

Codex wajib:

- membaca `git status`, branch aktif, dan HEAD sebelum bekerja;
- berhenti bila ada perubahan pengguna yang belum di-commit;
- tidak menjalankan `reset --hard`, `clean -fd`, force push, rebase interaktif, atau history rewrite;
- tidak menghapus file yang belum dipastikan obsolete;
- tidak merge ke main;
- tidak deploy;
- tidak mengubah secret atau `.env`;
- membuat commit hanya setelah test checkpoint lulus.

## 3. Checkpoints

### Checkpoint 0 — Read-only audit

Tidak mengubah repository.

Output:

- current route/component map;
- upload/record pipeline map;
- capability matrix: single/multi-file, MIME, size/count limits, chunking, progress, retry, browser-bound/server-bound;
- regression risks;
- proposed component architecture;
- safest activation strategy: feature flag, internal route, atau component switch mengikuti convention repo;
- exact file plan;
- test plan;
- blockers dan questions.

Berhenti dan tunggu persetujuan.

### Checkpoint 1 — Safety baseline and component boundaries

- buat branch setelah working tree bersih;
- tambah/rapikan test baseline untuk flow yang sudah ada;
- ekstrak component boundaries tanpa redesign besar;
- pisahkan backend/service calls dari presentational state;
- pertahankan auth, recording, upload, summary, folder, share, chat, billing scaffold, dan permissions;
- jangan mengubah API/database.

Berhenti, test, commit, dan laporkan.

### Checkpoint 2 — Design system and App Shell

- semantic tokens Light/Dark/System;
- sidebar desktop/compact/mobile;
- utility topbar;
- route shell;
- focus management dan responsive foundation;
- asset slots seperti `BrandMark`, `Wordmark`, dan `ProcessingMark` agar hasil Brand workstream dapat diganti tanpa refactor besar.

Berhenti, screenshot, test, commit, dan laporkan.

### Checkpoint 3 — Home, Courses, Shared, and Notara foundations

- Home returning dan first-use;
- processing/continuation modules;
- Courses dan Shared sesuai canonical spec;
- Notara workspace foundation tanpa membuat retrieval/provenance baru;
- Study Canvas dan Learning Lab hanya shell preview/foundation;
- `Belajar apa dulu?` tidak boleh mengunci recommendation engine baru. Gunakan adapter/fallback existing atau presentation shell yang dapat diganti setelah Learning System sync.

Berhenti, screenshot, test, commit, dan laporkan.

### Checkpoint 4 — Capture UX state model and presentation

Implementasikan kontrak `NOTARA_UPLOAD_FEEDBACK_AND_RECOVERY_UX_V1.md` pada frontend:

- drag feedback;
- selected-file preview;
- independent item rows;
- honest progress presentation;
- explicit success;
- inline failure and retry;
- replace/remove;
- accessibility.

Gunakan fake adapter/test fixtures hanya untuk unit/component test. Jangan mengubah backend pada checkpoint ini.

Berhenti, screenshot semua state, test, commit, dan laporkan.

### Checkpoint 5 — Wire existing recording/upload/processing pipeline

Hubungkan UI Checkpoint 4 ke contract existing:

- direct multipart flow;
- existing browser chunk flow;
- existing summarize-transcript flow;
- existing tier/count/size/MIME rules;
- existing save/folder flow;
- existing errors.

Progress hanya ditampilkan bila dapat diukur. Stage server/browser yang tidak memiliki percent memakai stage copy, bukan fake 0–100.

Retry mempertahankan file/chunk hanya sejauh arsitektur existing memungkinkan. Jangan menjanjikan persistence setelah refresh/tab close.

Berhenti, test small/large/silent/failure paths, commit, dan laporkan.

### Checkpoint 6 — Responsive, accessibility, and regression QA

Wajib mencakup:

- 1440×1000;
- 1280×720;
- 1024×900;
- 390×844;
- Light/Dark/System;
- sidebar/drawer;
- drag/drop and keyboard upload;
- multi-item queue;
- per-item retry;
- recording;
- processing;
- auth/session;
- folder/save;
- existing summary/chat/share routes;
- no blocking console error;
- build/lint/typecheck/tests.

Buat QA report dan screenshot index. Jangan merge.

### Checkpoint 7 — Handoff and merge-readiness gate

- update docs owner yang memang terdampak;
- changelog;
- implementation notes;
- remaining backend-dependent UX gaps;
- diff summary;
- rollback plan;
- merge readiness recommendation.

Tunggu sinkronisasi HQ untuk perubahan Learning System/Brand yang memengaruhi shell. Jangan merge atau deploy otomatis.
