# Notara Upload Feedback and Recovery UX V1

> **Status:** low-regret frontend UX addendum untuk implementasi App Shell V4.1.4.  
> **Sumber inspirasi:** enam screenshot pada `references/upload-ux-patterns/`.  
> **Yang diambil:** prinsip perilaku dan informasi.  
> **Yang tidak diambil:** dark/neon UI, grid background, visual copy, typography, dan layout presentasi.

## 1. Inti pola dari screenshot

### Signal 01 — Drag feedback

Dropzone harus menjawab saat file masuk ke area drop. Pengguna perlu melihat bahwa sistem:

- mendeteksi drag;
- mengenali file yang dibawa;
- menilai valid/invalid;
- siap menerima drop.

Feedback tidak hanya berupa glow. Gunakan perubahan border, icon, copy, dan metadata file yang terbaca.

### Signal 02 — Honest progress

Spinner tanpa informasi menyembunyikan keadaan. Saat upload berlangsung, tampilkan hanya informasi yang benar-benar dapat diukur:

- percent upload;
- bytes terkirim / total;
- waktu berlalu;
- estimasi waktu tersisa bila sampel cukup stabil;
- kecepatan bila tersedia;
- apa yang sedang dilakukan;
- apakah pengguna harus tetap membuka tab.

Setelah bytes selesai dikirim, percent upload harus berhenti pada terminal state dan UI berpindah ke tahap processing. Jangan mempertahankan `100% uploading` sambil server masih memproses.

### Signal 03 — Inline retry

Failure muncul pada item yang gagal, dekat progress dan file context. File lain tidak berubah. Retry tidak menjadi toast global tanpa konteks.

Bila File object masih berada di memory, pertahankan selection dan izinkan retry. Jangan mengklaim file tetap tersedia setelah refresh/tab close.

### Signal 04 — Upload preview

Filename saja bukan proof yang cukup. Sebelum submit/process, tampilkan preview yang relevan untuk input Notara:

- filename;
- media type/extension;
- file size;
- duration bila browser dapat membaca metadata;
- source: rekaman atau upload;
- status validasi;
- Replace dan Remove;
- destination/course bila sudah dipilih.

Notara menerima audio/video sesuai repository. Jangan meniru contoh image/PDF dari screenshot jika format tersebut tidak didukung. Untuk audio gunakan media icon/waveform ringan; untuk video gunakan poster frame hanya bila murah dan aman.

### Signal 05 — Independent queue

Setiap file memiliki lane dan state sendiri. Satu failure tidak menghapus atau memblokir hasil file lain.

Independent UX tidak berarti network harus paralel. Bila current implementation memproses maksimal tiga file secara sequential, pertahankan limit dan transport tersebut, tetapi simpan state per item:

- queued;
- preparing;
- uploading;
- transcribing;
- summarizing;
- saving;
- succeeded;
- failed;
- cancelled.

Retry, remove, dan status harus bekerja per item.

### Safe completion

Success harus eksplisit:

- icon/label selesai;
- filename;
- next action yang jelas;
- tidak ada spinner yang terus hidup;
- live announcement yang tidak berulang.

## 2. State model konseptual

Codex boleh menyesuaikan nama dengan architecture repo, tetapi state harus setara:

```ts
type CaptureTaskStatus =
  | 'selected'
  | 'queued'
  | 'preparing'
  | 'uploading'
  | 'transcribing'
  | 'summarizing'
  | 'saving'
  | 'succeeded'
  | 'failed'
  | 'cancelled';
```

Setiap task minimal memiliki:

- stable local id;
- `File`/recording reference selama session;
- filename, MIME, size, optional duration;
- status dan stage;
- measurable bytes/percent bila tersedia;
- started time;
- smoothed rate and ETA hanya bila valid;
- error code/message;
- retryability;
- attempt count;
- current destination/folder;
- indication whether file is still held in memory.

## 3. Honest progress rules

### Direct upload

- Gunakan real upload progress event bila transport mendukung.
- Bila current `fetch` tidak menyediakan upload progress, Codex boleh mengevaluasi XHR untuk client transport dengan endpoint/auth/error contract yang sama.
- Perubahan transport hanya boleh dilakukan setelah regression test; route server tidak berubah.

### Large/chunked audio

- Aggregate progress dari bytes/chunks yang benar-benar selesai.
- Tampilkan `Bagian X dari Y` jika lebih jujur daripada percent.
- Browser decode/resample yang tidak menyediakan progress memakai indeterminate stage copy: `Menyiapkan audio di perangkat ini`.
- Jangan membuat percent palsu untuk decode atau summary generation.

### Server/browser processing

Setelah upload selesai, gunakan stage labels seperti:

- `Mengunggah audio`;
- `Menyiapkan audio`;
- `Mentranskripsikan bagian 2 dari 8`;
- `Menggabungkan transkrip`;
- `Membuat rangkuman`;
- `Menyimpan materi`.

Tahap yang tidak measurable tidak menampilkan ETA numerik.

### ETA dan speed

- Jangan tampilkan sebelum memiliki sampel cukup.
- Gunakan rolling/smoothed rate agar tidak jitter.
- Labeli sebagai `Perkiraan` bila tidak deterministik.
- Hilangkan speed/ETA setelah upload transport selesai.
- Jangan menampilkan `0 detik tersisa` ketika processing masih berjalan.

## 4. Leave guidance

Screenshot mengajarkan memberi pengguna keputusan, bukan selalu menjanjikan mereka boleh pergi.

Current Notara menjalankan sebagian flow besar di browser. Karena itu copy harus mengikuti capability hasil audit:

- `Tetap buka tab ini sampai selesai` bila process browser/request-bound;
- `Kamu boleh membuka bagian lain di Notara` hanya jika state/task tidak terputus oleh navigation;
- `Aman menutup halaman` hanya jika ada background/server job yang benar-benar bertahan—capability ini tidak boleh diasumsikan pada workstream frontend ini.

Aktifkan `beforeunload` warning hanya selama task aktif dan hanya bila meninggalkan halaman berisiko membatalkan proses.

## 5. Retry semantics

- Error berada pada item yang gagal.
- Retry button menunjukkan stage yang akan dicoba ulang.
- Pertahankan progress sebelumnya bila current chunk flow dapat melanjutkan dari failed chunk.
- Bila current architecture hanya mendukung restart, jelaskan `Coba unggah ulang file ini`; jangan menyebut resume.
- File yang sukses tidak diulang ketika item lain gagal.
- Remove/cancel meminta konfirmasi bila task sedang aktif.
- Global error/toast hanya sebagai tambahan, bukan satu-satunya feedback.

## 6. Queue rules

- Baca limit count, size, MIME, dan sequential behavior dari repository aktif.
- Jangan hard-code lima file dari screenshot.
- Jika current limit adalah tiga file sequential, UI harus menyatakan limit tersebut.
- Satu row per item.
- Queue summary dapat menampilkan `2 selesai • 1 gagal`.
- Failure satu item tidak menghapus selection atau result item lain.
- Concurrency tidak boleh dinaikkan tanpa audit rate limits dan browser memory.

## 7. Drag/drop and validation

State minimum:

- idle;
- drag valid;
- drag invalid;
- dropped/selected;
- validation failed.

Feedback harus mencakup:

- border/surface/icon/copy;
- nama dan ukuran file bila aman;
- reason bila invalid;
- browse button sebagai alternatif;
- keyboard-operable input;
- no drag-only interaction.

## 8. Visual translation ke Notara V4

Gunakan canonical semantic tokens:

- action/cobalt untuk action normal;
- knowledge/teal untuk accepted/complete knowledge transfer;
- review/amber untuk waiting or needs attention;
- danger/red untuk failure;
- violet terbatas untuk brand moments.

Dilarang menyalin:

- background grid gelap;
- neon border/glow;
- monospace headline;
- English slogans;
- card proportions dari screenshot;
- red/teal sebagai decorative contrast.

## 9. Accessibility

- Dropzone memiliki real file input dan keyboard trigger.
- Progress memakai native/ARIA progress semantics.
- Live region hanya mengumumkan perubahan penting, bukan setiap persen.
- Error dikaitkan dengan item dan Retry button.
- Color bukan satu-satunya pembeda.
- Touch target minimum 44×44 px.
- Reduced motion mematikan pulse/glow nonessential.
- Focus tidak hilang ketika row berubah state.

## 10. Acceptance criteria

- Drag masuk menghasilkan feedback langsung dan valid/invalid yang jelas.
- Selected file menampilkan metadata serta Replace/Remove.
- Upload percent berasal dari real transport/chunk data.
- Processing yang tidak measurable memakai stage label, bukan fake percent.
- Speed/ETA hanya muncul bila reliable.
- Success terminal dan spinner berhenti.
- Failure inline dan retryable per item.
- File sukses lain tidak terblokir oleh satu failure.
- Current file limits dan sequential behavior dipertahankan.
- Copy leave/wait sesuai capability nyata.
- UX terlihat sebagai Notara V4, bukan salinan UI screenshot.
