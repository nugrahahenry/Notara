# Notara App Shell V4.1.4 — Codex Implementation Pack v1.0

This pack is for repository implementation, not standalone prototyping.

## Recommended branch

`feat/app-shell-v4-1-4-integration`

## Backend policy

- Existing backend is reused.
- No new API, migration, background job, or provider capability is added.
- Frontend must never claim progress, resumability, or leave-page safety that the runtime cannot support.

## Start

Read `START-HERE.md`, then run Checkpoint 0 only.
