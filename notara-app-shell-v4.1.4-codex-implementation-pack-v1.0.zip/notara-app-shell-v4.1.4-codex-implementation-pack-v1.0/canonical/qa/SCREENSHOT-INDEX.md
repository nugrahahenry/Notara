# Screenshot Index

- `01-home-light.png` — Home Light Editorial.
- `02-home-dark.png` — Dark Companion.
- `03-shared-from-friends.png` — inbound sharing.
- `04-shared-my-links.png` — outbound sharing.
- `05-notara-history.png` — desktop history utility.
- `06-mobile-notara-history.png` — mobile history drawer.
- `07-learning-path-cost.png` — Learning Path foundation.
- `08-mobile-home.png` — mobile Home.
