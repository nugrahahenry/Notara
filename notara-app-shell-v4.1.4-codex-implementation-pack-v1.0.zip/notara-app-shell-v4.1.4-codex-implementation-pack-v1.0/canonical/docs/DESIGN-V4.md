# Notara Design V4 — Light Editorial Shell, Adaptive Themes, and Brand Direction

> **Status:** canonical design direction untuk App Shell V4.1.4; fitur mendalam tetap belum final production.  
> **Tanggal sinkronisasi:** 30 Juli 2026.  
> **Baseline aktif:** **Light Editorial Continuum** dengan adaptive navigation dan contextual learning foundation.  
> **Mode utama saat review:** Light.  
> **Mode pendamping:** Dark dan System.  
> **Canonical prototype:** `notara-app-shell-home-brand-v4.1.4-final.html`.  
> **Bukan owner:** scope produk, API, backend, database, atau kontrak Speaker Context.

## 1. Alasan revisi

Visual Option A sebelumnya masih memiliki sidebar sangat gelap dan mark huruf `N` di kotak ungu. Setelah direview, kombinasi tersebut terlalu kontras terhadap workspace dan reading canvas terang. Efeknya membuat Notara kembali terasa seperti dashboard AI gelap yang ditempeli dokumen putih.

Revisi ini mengubah fondasi tersebut:

- light mode memakai shell terang, bukan dark sidebar;
- dark mode mengubah seluruh environment secara konsisten, bukan hanya sidebar;
- perbedaan surface dibangun melalui tonal steps, divider, selected state, dan typography;
- identitas tidak dikunci pada `N` dalam kotak gradient;
- kreativitas datang dari learning interaction, source trail, annotation, dan contextual tools;
- V4 tetap clean rebuild dan tidak mewarisi struktur visual V2/V3.

## 2. Keputusan yang dikunci

1. Light mode menjadi presentasi awal prototype dan fokus validasi pertama.
2. System tetap menjadi pilihan default produk; prototype boleh pertama kali tampil dalam Light agar arah visual dapat dinilai jelas.
3. Dalam Light mode, sidebar, header, workspace, dan Study Canvas berada pada satu keluarga terang dengan level tonal berbeda.
4. Dark sidebar permanen dilarang pada Light mode.
5. Dark mode merupakan companion theme yang mengubah seluruh surface secara konsisten.
6. Study Canvas tetap menjadi permukaan paling nyaman untuk membaca, tetapi tidak terlihat seperti kartu dokumen mengambang dengan shadow besar.
7. Learning Lab memakai tool rail + active panel.
8. Tutor Materi dipresentasikan sebagai Study Dock yang menyatu dengan canvas.
9. Violet adalah brand accent; cobalt adalah action; teal adalah knowledge/source; amber adalah review.
10. Logo lama dan mark `N` bukan aset wajib dan bukan placeholder yang boleh dijadikan identitas final tanpa alasan.
11. Prototype hanya membuat satu brand candidate yang terintegrasi, bukan banyak opsi logo.
12. Brand candidate mengutamakan gagasan `signal → note → understanding`, bukan monogram generik.
13. V4 dibangun dari file kosong dan tidak memakai prototype V2/V3 sebagai base.
14. Landing page belum dikerjakan pada iterasi App Shell.
15. Semua keputusan masih dapat direfine setelah usability test, tetapi tidak boleh kembali ke pola dark-AI-dashboard tanpa bukti kuat.

## 3. North star

Notara harus terasa seperti:

> **ruang belajar digital yang terang, tenang, dan responsif terhadap konteks mahasiswa.**

Dalam Light mode, Notara terasa seperti meja belajar editorial modern. Dalam Dark mode, Notara terasa seperti ruang belajar malam yang lembut. Identitasnya muncul melalui proporsi, annotation, source connection, dan motion yang bermakna—bukan melalui kontras hitam-putih ekstrem.

Karakter:

- akademik tetapi tidak kaku;
- modern dan relevan untuk mahasiswa Indonesia;
- kreatif melalui interaction;
- nyaman untuk membaca panjang;
- premium melalui hierarchy dan detail;
- AI hadir sebagai intelligence layer, bukan maskot utama;
- bukan chatbot dengan dokumen sebagai attachment;
- bukan cyberpunk cockpit;
- bukan card soup;
- bukan landing page di dalam aplikasi.

## 4. Prinsip visual utama

### 4.1 Tonal continuity

Perpindahan antarsurface harus terasa bertahap:

```text
Light mode:
soft-light sidebar → cool-neutral workspace → warm reading canvas

Dark mode:
soft-dark sidebar → dark-neutral workspace → slightly elevated reading canvas
```

Tidak boleh ada lompatan ekstrem seperti:

```text
black sidebar → bright grey workspace → pure white document card
```

### 4.2 Reading-first hierarchy

- Canvas mendapat hierarchy tertinggi melalui measure, typography, dan whitespace.
- Sidebar tetap jelas tetapi tidak lebih dominan daripada materi.
- Header ringkas dan tidak menjadi slab terpisah.
- Learning Lab terasa seperti alat, bukan panel konten kedua yang bersaing.
- Primary action tidak selalu menjadi elemen paling besar.

### 4.3 Kreatif pada interaction, tenang pada tampilan

Kreativitas relevan:

- Study Dock mengenali konteks teks/formula;
- source trail kembali ke paragraf atau timestamp;
- annotation layer untuk highlight, note, dan pertanyaan;
- contextual suggestion di Learning Lab tanpa mengambil alih pilihan pengguna;
- formula evidence progressive disclosure;
- motion recording/processing yang menjelaskan state.

Kreativitas yang dilarang:

- glow pada semua surface;
- gradient pada setiap tombol;
- orbit sebagai dekorasi berulang;
- kartu untuk setiap section;
- animasi yang tidak menjelaskan state;
- chatbot besar yang selalu terbuka.

## 5. Semantic color system

Komponen memakai semantic token. Warna mentah hanya didefinisikan pada theme.

```css
--surface-app;
--surface-sidebar;
--surface-header;
--surface-canvas;
--surface-tool;
--surface-elevated;
--surface-overlay;

--text-primary;
--text-secondary;
--text-tertiary;
--text-on-brand;

--border-subtle;
--border-strong;

--brand-primary;
--brand-secondary;
--action-primary;
--action-primary-hover;
--knowledge-accent;
--review-accent;
--success-accent;
--danger-accent;

--nav-selected;
--nav-selected-text;
--focus-ring;
--selection-fill;
```

### 5.1 Light theme — primary approved direction

```css
[data-theme="light"] {
  --surface-app: #eceef2;
  --surface-sidebar: #f5f4f1;
  --surface-header: #eceef2;
  --surface-canvas: #fbf8f1;
  --surface-tool: #f3f5f8;
  --surface-elevated: #ffffff;
  --surface-overlay: #ffffff;

  --text-primary: #182136;
  --text-secondary: #4a566b;
  --text-tertiary: #70798b;
  --text-on-brand: #ffffff;

  --border-subtle: #d8dee7;
  --border-strong: #bcc5d1;

  --brand-primary: #7058e8;
  --brand-secondary: #596ee6;
  --action-primary: #4661d8;
  --action-primary-hover: #394fc0;
  --knowledge-accent: #16868c;
  --review-accent: #b87820;
  --success-accent: #24734f;
  --danger-accent: #b34b52;

  --nav-selected: #ebe8fb;
  --nav-selected-text: #4f3eb8;
  --focus-ring: #4661d8;
  --selection-fill: rgba(22, 134, 140, 0.18);
}
```

Light mode rules:

- sidebar bukan putih murni dan bukan hitam; gunakan warm neutral tint;
- header menyatu dengan workspace;
- canvas adalah warm ivory, bukan pure white;
- selected navigation memakai tint lembut + accent line/icon;
- button primary memakai cobalt solid;
- violet tidak dipakai pada semua CTA;
- shadow maksimal sangat tipis dan hanya untuk overlay/floating dock.

### 5.2 Dark theme — companion direction

```css
[data-theme="dark"] {
  --surface-app: #14161c;
  --surface-sidebar: #191b23;
  --surface-header: #14161c;
  --surface-canvas: #20232a;
  --surface-tool: #252934;
  --surface-elevated: #2a2e38;
  --surface-overlay: #2d313c;

  --text-primary: #f1f2f6;
  --text-secondary: #c0c5d0;
  --text-tertiary: #949cab;
  --text-on-brand: #ffffff;

  --border-subtle: #343944;
  --border-strong: #4a5060;

  --brand-primary: #9b86f7;
  --brand-secondary: #8493f4;
  --action-primary: #7d8bf2;
  --action-primary-hover: #929df7;
  --knowledge-accent: #58b9be;
  --review-accent: #d7a35a;
  --success-accent: #70bb93;
  --danger-accent: #df7f86;

  --nav-selected: #2d2945;
  --nav-selected-text: #c9beff;
  --focus-ring: #a7b0ff;
  --selection-fill: rgba(88, 185, 190, 0.22);
}
```

Dark mode rules:

- tidak memakai pure black;
- canvas tetap berbeda dari workspace tetapi tidak menjadi white paper;
- aksen tidak neon;
- shadow diganti dengan tonal elevation dan border;
- formula/source/review tetap memiliki meaning yang sama seperti Light mode.

### 5.3 System behavior

- pilihan theme: `System`, `Light`, `Dark`;
- System mengikuti `prefers-color-scheme`;
- preferensi disimpan;
- tidak ada flash theme yang berat;
- perubahan theme tidak mengubah layout;
- contrast dan state diuji pada kedua theme.

## 6. Contrast ladder

Hierarchy surface pada Light mode:

| Layer | Fungsi | Target |
|---|---|---|
| Sidebar | Orientasi dan navigasi | lembut, tidak dominan |
| Workspace | latar aktivitas | cool-neutral |
| Canvas | membaca dan memahami | warm, paling nyaman |
| Elevated | popover/modal/dock | putih dengan border |
| Tool | Learning Lab | neutral sedikit berbeda |

Aturan:

- hindari lompatan luminance ekstrem;
- gunakan border `1px`, spacing, dan typography sebelum shadow;
- sidebar aktif dibedakan dengan tint dan accent, bukan blok gelap;
- canvas tidak boleh terlihat seperti PDF card yang mengambang;
- pada 1280×720, shell tetap ringan dan content density terkendali.

## 7. Typography

### UI

- pilihan utama: Plus Jakarta Sans;
- fallback: Geist, Inter, system sans-serif;
- body UI: 14–16 px;
- metadata penting: minimum 12 px;
- target sentuh: minimum 44 px.

### Reading

- pilihan utama: Source Serif 4 atau serif editorial yang bersih;
- body reading: minimum 16 px;
- line-height: 1.65–1.8;
- measure ideal: 680–740 px;
- heading tidak terlalu dekoratif.

### Formula/code

- math renderer nyata bila tersedia;
- fallback plain text wajib;
- monospace hanya untuk timestamp, code, dan metadata teknis.

## 8. App Shell

### 8.1 Sidebar Light mode

- expanded: 224–232 px;
- collapsed: 68–72 px;
- background warm-light neutral;
- selected item memakai lavender tint atau subtle line;
- icon default graphite; selected icon violet/cobalt;
- Rekam/Upload tetap mudah ditemukan tetapi tidak menjadi tombol gradient besar;
- profile berada di bawah;
- collapse state memiliki tooltip.

### 8.2 Header

- tinggi 64–72 px;
- menyatu dengan workspace;
- tidak menggunakan black slab;
- route title dan context berada di kiri;
- action sekunder di kanan;
- breadcrumb/metadata ringkas;
- tidak menduplikasi Global Tutor sebagai CTA besar jika sudah ada di sidebar.

### 8.3 Mobile shell

- sidebar menjadi drawer;
- top bar tetap ringan;
- brand mark terbaca pada 24–32 px;
- overlay mengembalikan focus ke trigger;
- safe area dan virtual keyboard diperhitungkan.

## 9. Home aplikasi

Home untuk returning user berorientasi continuation:

1. sapaan ringkas;
2. processing aktif/gagal;
3. lanjutkan belajar;
4. materi terbaru;
5. mata kuliah;
6. Rekam/Upload sebagai utility.

Larangan:

- upload hero besar sebagai pusat Home returning user;
- dashboard penuh metrik generik;
- card grid seragam untuk semua informasi;
- chat panel permanen.

Gunakan editorial grouping, rows, timeline, dan satu featured continuation block. Kartu hanya dipakai ketika grouping membutuhkan boundary.

## 10. Study Canvas presentation

- warm editorial canvas menyatu dengan workspace;
- reading measure 680–740 px;
- canvas boleh memiliki border tipis tanpa shadow besar;
- section menggunakan spacing dan divider, bukan card;
- source, formula, quote, dan answer memakai treatment berbeda berdasarkan fungsi;
- Rangkuman/Transkrip control ringkas;
- canvas menjadi pusat visual tanpa terlihat seperti PDF viewer.

## 11. Study Dock

Idle:

```text
[brand mark] Tanya materi ini…      Pertemuan 04      ↑
```

- tinggi 52–56 px;
- menyatu dengan canvas atau berada tepat di bawahnya;
- border lembut;
- shadow sangat kecil bila floating;
- scope terlihat tetapi tidak dominan.

Expanded:

- tinggi sekitar 116–140 px;
- context chip;
- suggestion;
- thread count;
- textarea;
- send action;
- pada mobile tidak terbuka bersamaan dengan Learning Lab bottom sheet.

## 12. Learning Lab

Desktop menggunakan:

- tool rail 44–48 px;
- active tool panel 256–288 px;
- lima area tetap: Konsep, Rumus, Visual, Quiz, Pembicara;
- tooltip pada rail;
- selected state jelas;
- contextual suggestion tidak mengganti pilihan pengguna secara tiba-tiba.

Tablet/mobile:

- drawer atau bottom sheet;
- satu tool aktif dalam satu waktu;
- close dan back behavior jelas;
- tidak menutupi Study Dock/keyboard.

## 13. Formula treatment

Default menampilkan:

- label formula;
- timestamp/source;
- review state;
- formula;
- ringkasan satu kalimat;
- `Periksa bukti` dan `Tanya formula`.

Evidence, raw utterance, koreksi, confirm/reject, variable explanation, dan private note berada pada progressive disclosure. Jangan tampilkan semua detail secara bersamaan.

## 14. Brand candidate V4

### 14.1 Status

Brand masih terbuka. Prototype harus menampilkan satu kandidat yang cukup matang untuk diuji, tetapi tidak diklaim sebagai final production asset.

### 14.2 Arah konsep

Arah kandidat yang disarankan:

> **Signal Fold** — sinyal audio yang bertransformasi menjadi margin, annotation, atau struktur catatan.

Makna:

- audio masuk;
- informasi ditata;
- pemahaman terbentuk;
- satu endpoint/dot dapat mewakili fokus atau source.

### 14.3 Yang dilarang

- huruf `N` di kotak gradient sebagai default;
- robot;
- brain icon;
- sparkle AI;
- chat bubble utama;
- play button generik;
- waveform literal tanpa transformasi;
- banyak opsi logo dalam UI utama.

### 14.4 Persyaratan

- inline SVG bersih;
- terbaca pada 16, 24, 32, dan 48 px;
- bekerja pada light/dark/monochrome;
- dapat dipakai pada sidebar collapsed dan mobile;
- wordmark lowercase `notara` boleh digunakan selama typography sesuai;
- label `Brand candidate V4` hanya muncul pada About/Prototype panel.

## 15. Motion

Motion hanya untuk:

- recording;
- processing;
- source jump;
- Study Dock expand/collapse;
- drawer/modal transition;
- feedback state.

Durasi umum 140–220 ms. Orbit/wave motion tidak menjadi dekorasi terus-menerus. Hormati `prefers-reduced-motion`.

## 16. Accessibility

- WCAG-oriented contrast;
- visible focus pada Light dan Dark;
- state tidak hanya memakai warna;
- keyboard navigation;
- semantic HTML;
- ARIA untuk tabs, drawer, modal, expanded state, toast/live region;
- focus return;
- touch target minimum 44 px;
- reading body minimum 16 px;
- formula dan transcript tidak menyebabkan page-level overflow.

## 17. Frontend clean-rebuild rules

- mulai dari file kosong;
- tidak membaca atau mengedit source prototype V2/V3;
- tidak membawa theme system lama;
- tidak menumpuk CSS override;
- semantic tokens menjadi fondasi;
- DOM, CSS, dan JavaScript baru;
- state management dan rendering dipisahkan;
- localStorage prefix `notara-prototype-v4-`;
- no backend/fake endpoint;
- mock diberi disclosure.

## 18. Acceptance criteria App Shell V4

Prototype dianggap layak direview bila:

- Light mode jelas menggunakan light sidebar dan tonal continuity;
- tidak ada dark sidebar pada Light mode;
- Dark mode mengubah seluruh environment secara konsisten;
- Home returning user berorientasi continuation;
- header ringkas;
- Study Canvas terasa editorial dan menyatu;
- Learning Lab memakai tool rail;
- Study Dock idle/expanded berfungsi;
- Global Tutor tetap workspace terpisah;
- satu brand candidate non-generic terintegrasi;
- mark bukan `N` dalam kotak gradient;
- responsive 1440, 1280×720, 1024, 768, dan 390 px;
- keyboard/focus/theme persistence bekerja;
- hasil tidak terasa sebagai recolor desain lama.

## 19. Sinkronisasi keputusan App Shell V4.1.4

Bagian ini mengikat keputusan yang telah terbukti pada prototype canonical.

### 19.1 Notara sebagai product intelligence layer

Nama `Global Tutor` tidak lagi menjadi label utama. Entry point aplikasi adalah:

```text
Tanya Notara
Notara — Pemandu belajar lintas materi
```

Notara dapat berpindah scope tanpa memutus percakapan:

- semua materi;
- satu mata kuliah;
- satu materi tertentu.

Perubahan scope harus terlihat sebagai system event. Ketika scope berupa satu materi, tersedia jalur `Buka materi` dan `Lanjutkan di Tutor Materi`.

### 19.2 Home sebagai learning continuation

Home menggabungkan:

- greeting berbasis waktu lokal;
- ambient scene pagi/siang/sore/malam;
- processing priority;
- `Belajar apa dulu?` sebagai foundation Learning Path;
- Continue Learning;
- materi terbaru;
- mata kuliah;
- Record / Upload.

Greeting tidak boleh menjadi hero dekoratif kosong. Ambient scene harus mendukung orientasi waktu dan tetap ringan.

### 19.3 Adaptive navigation

Sidebar memiliki tiga perilaku:

- desktop expanded 232 px;
- desktop/tablet compact 72 px;
- mobile drawer.

Toggle expand/collapse harus selalu dapat ditemukan. State dapat disimpan. Pada laptop/tablet, perluasan tidak menggunakan backdrop blur yang mengunci workspace.

### 19.4 Topbar

Topbar menjadi global utility bar. Page title hanya muncul sekali di page hero/body.

Topbar dapat memuat:

- navigation trigger;
- search/command palette;
- contextual action;
- record action;
- profile/settings.

Topbar tidak mengulang `Beranda`, `Mata Kuliah`, `Dibagikan`, atau `Notara` sebagai title kedua.

### 19.5 Directional sharing

Halaman Dibagikan membedakan dua aliran:

- **Dari teman:** materi bergerak masuk menuju ruang belajar pengguna;
- **Link saya:** akses bergerak keluar dari pengguna menuju penerima.

Filter mengubah animasi, cards, copy, metrics, dan actions. Animasi berfungsi sebagai penjelasan arah sharing, bukan dekorasi.

### 19.6 Riwayat Notara

Riwayat adalah utility drawer/collapsible panel, bukan sidebar aplikasi kedua.

- default dapat disembunyikan;
- panel dapat dipin pada desktop lebar;
- chat dapat dipin secara individual;
- rename/delete berada di samping judul chat atau overflow menu;
- delete memiliki undo;
- pin panel dan pin chat adalah dua konsep berbeda.

### 19.7 Learning Lab boundary

App Shell hanya mengunci foundation:

- docked pada desktop;
- compact rail/expandable pada tablet;
- bottom sheet pada mobile;
- tidak memakai backdrop blur pada desktop/tablet;
- tool memiliki icon dan label;
- Study Dock dan mobile sheet tidak saling bertabrakan.

Mind Map, Quiz, Audio Overview, Slide Deck, source-linked behavior, generation flow, dan multi-scope Learning Lab belum dianggap final. Semua akan dibedah pada workstream terpisah.

### 19.8 Cross-material learning foundation

Home boleh menampilkan rekomendasi `Belajar apa dulu?`, alasan, prasyarat, estimasi, dan urutan. Namun recommendation engine belum dianggap production contract sampai brainstorm dan validasi berikutnya selesai.

### 19.9 Signal Fold

Signal Fold tetap brand candidate:

- bekerja pada light/dark/monochrome;
- dibaca sebagai signal yang berubah menjadi annotation/struktur;
- tidak boleh dikunci sebagai logo final sebelum asset workstream selesai;
- asset exploration tidak boleh menghidupkan kembali `N` gradient generik.

## 20. App Shell canonical acceptance

App Shell V4.1.4 menjadi canonical reference karena:

- light warm-neutral sidebar dan tonal continuity terjaga;
- dark mode mengubah seluruh environment;
- sidebar expanded/collapsed/mobile drawer berfungsi;
- Home first-use dan returning state tersedia;
- directional sharing tersedia;
- Notara scope continuation tersedia;
- riwayat tidak menjadi sidebar kedua permanen;
- Study Canvas, Study Dock, dan Learning Lab memiliki foundation responsive;
- tidak ada horizontal overflow atau blocking console error pada viewport QA;
- fitur mendalam tetap diberi batas simulasi yang jujur.

Perubahan setelah versi ini harus berasal dari hasil brainstorm terarah, user research, accessibility audit, atau kebutuhan implementation—not from visual drift.
