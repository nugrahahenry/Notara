# Parallel Workstreams After App Shell

## Workstream A — Learning system brainstorm

Chat:

`Notara — Learning System, Study Journey & Learning Lab Brainstorm HQ`

Tujuan:

- membedah Learning Path;
- menentukan peran Notara;
- mendefinisikan scope Learning Lab;
- memprioritaskan Mind Map, Quiz, Audio, dan Slides;
- mengunci batas Study Canvas dan workspace global;
- menghasilkan dokumen keputusan sebelum V4.2.

Dilarang:

- langsung membangun prototype final;
- mengubah App Shell canonical tanpa alasan;
- mendesain landing page;
- membuat backend/API.

## Workstream B — Brand dan aset

Chat:

`Notara — Brand, Signal Fold & Product Asset Direction`

Tujuan:

- refine Signal Fold;
- menentukan icon set;
- menghasilkan processing/recording visuals;
- ambient Home assets;
- empty-state illustration system;
- source-linked learning visual language;
- light/dark/monochrome variants.

Dilarang:

- mengubah navigation hierarchy;
- membuat banyak logo tanpa selection framework;
- menghidupkan kembali dark AI slop;
- menganggap candidate sebagai final tanpa size/theme QA.

## Sinkronisasi

Kedua workstream kembali ke Product & Design Direction HQ ketika:

- ada keputusan yang mengubah design system;
- ada asset yang memerlukan layout baru;
- ada interaction yang harus masuk App Shell;
- sebelum produksi prototype V4.2.
