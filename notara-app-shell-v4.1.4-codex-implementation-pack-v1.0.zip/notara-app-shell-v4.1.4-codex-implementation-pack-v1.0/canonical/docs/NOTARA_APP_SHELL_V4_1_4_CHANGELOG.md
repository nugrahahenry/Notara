# Notara App Shell V4.1.4 — Canonical Changelog

## Dari V4.1.3 ke V4.1.4

### Notara

- `Tanya semua materi` menjadi `Tanya Notara`.
- Workspace diposisikan sebagai pemandu belajar lintas materi.
- Scope mendukung semua materi, mata kuliah, dan materi tertentu.
- Percakapan dipertahankan saat scope berubah.
- System event menjelaskan perubahan scope.
- Material scope menyediakan handoff ke Study Canvas dan Tutor Materi.

### Learning Path foundation

- Home menambahkan `Belajar apa dulu?`.
- Rekomendasi memuat alasan, prerequisite, estimasi, dan urutan.
- Pengguna dapat mengikuti atau menyusun ulang urutan.
- Tanya Notara dapat membawa konteks rekomendasi.

### Directional sharing

- Filter Semua, Dari teman, dan Link saya menjadi fungsional.
- Inbound dan outbound memiliki animasi, cards, metrics, copy, dan actions berbeda.

### Riwayat Notara

- Utility drawer, bukan sidebar permanen.
- Pin panel dan pin chat dibedakan.
- Aksi pin/delete di row chat.
- Delete mendukung undo.

### App Shell polish

- page title tidak diulang di topbar;
- sidebar expanded/collapsed/mobile drawer tetap berfungsi;
- theme Light/Dark/System tetap konsisten;
- Learning Lab tetap foundation;
- duplicate brand wrapper diperbaiki;
- mobile history dipulihkan.

## Status

V4.1.4 dikunci sebagai canonical App Shell reference. Pengembangan fitur berikutnya dilakukan pada workstream terpisah.
