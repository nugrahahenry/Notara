# Notara App Shell V4.1.4 — Canonical Specification

> **Status:** canonical prototype contract.  
> **Scope:** shell, Home, Courses, Shared, capture/processing foundation, Notara entry workspace, responsive navigation, theme, dan shell preview fitur belajar.

## 1. Tujuan

App Shell menyediakan orientasi utama pengguna sebelum masuk ke fitur belajar mendalam. Ia harus menjawab:

- saya sedang berada di mana;
- apa yang sedang diproses;
- materi mana yang sebaiknya dilanjutkan;
- bagaimana membuka mata kuliah atau materi;
- bagaimana merekam atau upload;
- bagaimana bertanya lintas materi kepada Notara;
- bagaimana masuk ke Study Canvas dan Learning Lab.

## 2. Information architecture

### Sidebar

1. Signal Fold + wordmark Notara.
2. Tanya Notara.
3. Beranda.
4. Mata Kuliah.
5. Dibagikan.
6. Daftar mata kuliah.
7. Rekam / Upload.
8. Profile.

### Route utama

- Home;
- Courses;
- Shared;
- Study Canvas preview;
- Notara workspace.

## 3. Navigation modes

### Desktop

- Expanded: 232 px.
- Collapsed: 72 px.
- Toggle selalu terlihat.
- State dapat dipersist.
- Content menyesuaikan lebar tanpa backdrop.

### Tablet/laptop compact

- Default compact.
- Dapat diperluas.
- Tidak mengunci workspace dengan full-screen blur.

### Mobile

- Drawer.
- Backdrop berada di bawah drawer.
- Escape/backdrop menutup.
- Focus kembali ke trigger.

## 4. Topbar

Topbar adalah utility layer, bukan page-title layer.

Wajib mendukung:

- mobile/sidebar trigger;
- search/command palette;
- contextual action;
- Record baru;
- settings/profile.

Page heading berada di body satu kali saja.

## 5. Home — returning user

Prioritas:

1. contextual greeting berbasis waktu perangkat;
2. active/failed processing;
3. `Belajar apa dulu?`;
4. Continue Learning;
5. materi terbaru;
6. mata kuliah;
7. capture utility.

### Daypart behavior

- pagi;
- siang;
- sore;
- malam.

Greeting, subcopy, dan ambient scene berubah. Scene menggunakan CSS/SVG ringan dan menghormati reduced motion.

### Belajar apa dulu?

Foundation harus dapat menampilkan:

- rekomendasi pertama;
- alasan;
- prerequisite;
- estimasi waktu;
- urutan;
- `Ikuti urutan`;
- `Atur sendiri`;
- `Tanya Notara`.

Urutan dapat disusun ulang dalam prototype. Engine rekomendasi belum production.

## 6. Home — first-use

Memuat:

- outcome Notara secara ringkas;
- Rekam dan Upload;
- preview Study Canvas;
- format/batas file yang jujur;
- privacy/process disclosure;
- tidak memakai landing-page hero berlebihan.

## 7. Record / Upload dan processing

### Capture state

- ready;
- permission request/denied;
- recording;
- paused;
- stopping;
- upload selected;
- drag/drop;
- uploading.

### Processing state

- upload complete;
- transcription;
- summary;
- concept/formula scan foundation;
- partial failure;
- failed/retry;
- success.

Mock state harus diberi disclosure prototype.

## 8. Mata Kuliah

Halaman bukan card grid generik semata. Ia menampilkan learning landscape:

- mata kuliah aktif;
- progress;
- materi terbaru;
- processing;
- continuation;
- hubungan aktivitas belajar.

Page title tidak diulang di topbar.

## 9. Dibagikan

### Filter

- Semua;
- Dari teman;
- Link saya.

### Dari teman

- arah animasi masuk;
- siapa membagikan;
- mata kuliah/pertemuan;
- waktu;
- permission;
- expiry;
- source availability;
- buka materi.

### Link saya

- arah animasi keluar;
- materi milik pengguna;
- jumlah pembuka/komentar;
- permission;
- expiry;
- salin link;
- kelola akses;
- nonaktifkan link.

Teal menandai inbound knowledge; violet menandai outbound link. Warna bukan satu-satunya pembeda.

## 10. Notara workspace

Label utama:

```text
Notara
Pemandu belajar lintas materi
```

### Scope

- semua materi;
- satu mata kuliah;
- satu materi tertentu.

Perubahan scope:

- tidak menghapus percakapan;
- menghasilkan system event;
- menyesuaikan composer dan source suggestions;
- untuk materi tertentu memberi `Buka materi` dan `Lanjutkan di Tutor Materi`.

### Riwayat

- utility drawer;
- dapat dipin sebagai panel desktop;
- pin per-chat;
- rename/delete melalui aksi di row;
- undo delete;
- mobile drawer.

Full retrieval, persistence, provenance, dan AI response belum production.

## 11. Study Canvas shell preview

App Shell hanya mengunci:

- editorial reading surface;
- Rangkuman/Transkrip preview;
- Study Dock idle/expanded;
- Learning Lab dock/rail/sheet foundation;
- back navigation;
- material context transfer dari Notara.

Formula Notes, Speaker Context, Quiz, inline tutor, dan source graph tidak diperdalam di sini.

## 12. Learning Lab foundation

### Desktop

- docked split workspace;
- no blur backdrop;
- tool rail + active panel.

### Tablet

- compact rail;
- expandable pane yang mendorong canvas;
- no full-screen blur.

### Mobile

- bottom sheet;
- safe area;
- tidak bertabrakan dengan Study Dock/keyboard.

Tool preview dalam prototype bersifat concept foundation. Product contract berikutnya ditetapkan pada brainstorm terpisah.

## 13. Theme

- System;
- Light;
- Dark.

Light memakai warm-neutral sidebar, cool workspace, warm canvas. Dark mengubah seluruh environment. Theme dipersist dan diterapkan sebelum first paint.

## 14. Brand

Signal Fold adalah candidate. Prototype harus:

- menampilkan inline SVG;
- bekerja kecil dan besar;
- memiliki light/dark treatment;
- tidak mengklaim final logo.

## 15. Accessibility dan responsive

- semantic HTML;
- keyboard/focus;
- visible focus;
- focus return;
- modal/drawer focus containment;
- reduced motion;
- touch target minimal 44 px;
- important metadata minimal 12 px;
- tidak ada page-level horizontal overflow;
- viewport canonical: 1440, 1280×720, 1024, 768, 390.

## 16. Non-goals

- landing page;
- full Learning Lab;
- recommendation engine production;
- full Notara retrieval/conversation backend;
- Formula Notes detail;
- Speaker Context detail;
- Quiz engine;
- PPTX/TTS/mind-map generation production;
- API/database/auth/billing changes.
