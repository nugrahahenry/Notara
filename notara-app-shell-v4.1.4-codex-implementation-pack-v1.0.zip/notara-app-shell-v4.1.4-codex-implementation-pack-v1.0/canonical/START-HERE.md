# START HERE — Notara App Shell V4.1.4 Canonical Handoff

> **Status:** App Shell canonical reference.  
> **Tanggal:** 30 Juli 2026.  
> **Versi paket:** 2.0.  
> **Prototype utama:** `prototype/notara-app-shell-home-brand-v4.1.4-final.html`.

## Tujuan paket

Paket ini menutup workstream App Shell dan menjadi satu-satunya handoff aktif untuk:

- App Shell;
- Home;
- Mata Kuliah;
- Dibagikan;
- navigation dan responsive behavior;
- Record / Upload serta processing foundation;
- Notara sebagai entry point pemandu belajar lintas materi;
- Study Canvas dan Learning Lab sebagai shell/foundation;
- Signal Fold sebagai brand candidate, bukan final production identity.

Paket ini menggantikan clean-rebuild pack v1.1/v1.2 dan handoff App Shell V4.1.2/V4.1.3.

## Source of truth

| Domain | Dokumen |
|---|---|
| Visual system dan shell | `docs/DESIGN-V4.md` |
| App Shell behavior dan state | `docs/NOTARA_APP_SHELL_V4_1_4_SPEC.md` |
| Nilai lintas materi yang akan dibedah | `docs/NOTARA_CROSS_MATERIAL_LEARNING_DIRECTION_V1.md` |
| Batas antar-workstream | `docs/NOTARA_PARALLEL_WORKSTREAMS_AFTER_APP_SHELL.md` |
| QA | `docs/NOTARA_APP_SHELL_V4_1_4_FINAL_QA.md` |
| Perubahan versi | `docs/NOTARA_APP_SHELL_V4_1_4_CHANGELOG.md` |

## Jangan gunakan kembali

- prototype V2/V3;
- App Shell V4.0–V4.1.3 sebagai base baru;
- prompt design brainstorm lama;
- dark-sidebar direction lama;
- logo `N` dalam kotak gradient;
- pack App Shell lama bersama paket ini.

Gunakan hanya prototype V4.1.4 dan dokumen canonical di paket ini.

## Chat berikutnya

### Brainstorm produk

`Notara — Learning System, Study Journey & Learning Lab Brainstorm HQ`

Gunakan:

`prompts/NOTARA_LEARNING_SYSTEM_BRAINSTORM_MASTER_PROMPT.md`

Chat ini belum memproduksi V4.2. Tugasnya membedah dan mengunci keputusan produk terlebih dahulu.

### Aset dan brand paralel

`Notara — Brand, Signal Fold & Product Asset Direction`

Gunakan:

`prompts/NOTARA_BRAND_AND_PRODUCT_ASSET_BRAINSTORM_PROMPT.md`

Workstream ini tidak boleh mengubah layout dan interaction contract App Shell tanpa keputusan dari Product & Design Direction HQ.

### Prototype berikutnya setelah brainstorm matang

`Notara — Study Canvas, Learning Path & Learning Lab V4.2`
