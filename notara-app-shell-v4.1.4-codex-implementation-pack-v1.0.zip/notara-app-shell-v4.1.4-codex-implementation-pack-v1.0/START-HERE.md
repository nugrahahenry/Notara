# START HERE — Notara App Shell V4.1.4 Codex Implementation Pack

> **Status:** implementation planning and execution pack.  
> **Target:** mengintegrasikan App Shell V4.1.4 ke repository aktif tanpa menambah fitur backend baru.  
> **Metode:** satu feature branch, beberapa checkpoint, berhenti untuk review setelah setiap checkpoint.  
> **Merge/deploy:** tidak dilakukan otomatis.

## Tujuan

Paket ini menjembatani prototype canonical App Shell V4.1.4 dengan source repository Notara. Ia juga menambahkan kontrak UX untuk Record / Upload yang berasal dari enam screenshot referensi.

Screenshot tersebut adalah **referensi perilaku**, bukan referensi visual. Jangan menyalin dark grid, neon teal/red, typography, card styling, glow, atau copy bahasa Inggrisnya. Visual production tetap mengikuti `canonical/docs/DESIGN-V4.md`.

## Urutan baca Codex

1. `ACTIVE-SOURCE-MANIFEST.md`.
2. `docs/BRANCH_AND_CHECKPOINT_PLAN.md`.
3. `docs/NOTARA_UPLOAD_FEEDBACK_AND_RECOVERY_UX_V1.md`.
4. `canonical/START-HERE.md`.
5. Seluruh canonical docs yang disebut manifest.
6. Repository aktif: root README, `spec/README.md`, PRD, FSD, API, Technical, Security, source code, migrations, dan tests.
7. `prompts/NOTARA_APP_SHELL_V4_1_4_CODEX_IMPLEMENTATION_MASTER_PROMPT.md`.

## Cara menjalankan

Buka Codex dari root repository Notara dan berikan paket ini. Kirim:

```text
Baca seluruh implementation pack dan repository aktif.
Ikuti prompts/NOTARA_APP_SHELL_V4_1_4_CODEX_IMPLEMENTATION_MASTER_PROMPT.md.
Jalankan Checkpoint 0 saja. Jangan mengubah file pada checkpoint ini.
```

Setelah menerima laporan Checkpoint 0, review dan lanjutkan satu checkpoint per instruksi eksplisit.
