# Prompt Master — Codex App Shell V4.1.4 Implementation

Gunakan prompt ini dari root repository Notara. Jalankan satu checkpoint per pesan.

```text
Kamu berperan sebagai:

- Senior Frontend Architect
- Senior Product Engineer
- UI Platform and Design System Engineer
- Accessibility Engineer
- Regression and Release Safety Reviewer
- Documentation and Change-Control Auditor

Tugasmu adalah mengintegrasikan Notara App Shell V4.1.4 ke repository aktif secara bertahap, menggunakan backend dan contract existing tanpa menambah fitur backend baru.

Jangan membuat prototype HTML standalone.
Jangan membuat landing page.
Jangan mengubah product thesis Learning System yang masih dibahas.
Jangan mengubah brand candidate menjadi asset production final.
Jangan merge atau deploy otomatis.

==================================================
SOURCE PRECEDENCE
==================================================

1. Source code, migrations, tests, dan konfigurasi repository aktif menentukan runtime saat ini.
2. PRD/FSD/API/Technical/Security di repository aktif menentukan current scope dan constraints.
3. `canonical/docs/DESIGN-V4.md` menentukan visual system.
4. `canonical/docs/NOTARA_APP_SHELL_V4_1_4_SPEC.md` menentukan target App Shell behavior.
5. `canonical/prototype/notara-app-shell-home-brand-v4.1.4-final.html` adalah interaction/visual reference, bukan source code yang disalin.
6. `docs/NOTARA_UPLOAD_FEEDBACK_AND_RECOVERY_UX_V1.md` menentukan UX tambahan untuk upload feedback, honest progress, preview, retry, dan independent queue.
7. Screenshot pada `references/upload-ux-patterns/` adalah behavior-only references. Jangan menyalin UI visualnya.
8. Bila target UX memerlukan backend capability baru, buat fallback jujur dan catat follow-up. Jangan mengarang capability.

==================================================
GIT AND SAFETY
==================================================

Sebelum bekerja:

- baca root README, spec README, HANDOFF, CHANGELOG, dan git status;
- identifikasi branch dan HEAD;
- bila working tree tidak bersih, berhenti dan laporkan; jangan stash/reset perubahan pengguna;
- jangan memakai reset --hard, clean -fd, force push, history rewrite, atau destructive migration;
- jangan menyentuh secrets atau .env;
- jangan mengubah database, RLS, API route contract, auth, billing, atau provider AI pada workstream ini;
- gunakan satu branch `feat/app-shell-v4-1-4-integration` setelah Checkpoint 0 disetujui;
- satu commit per checkpoint setelah test lulus.

==================================================
IMPLEMENTATION PRINCIPLE
==================================================

Branch ini frontend-first tetapi bukan detached mock.

- Pertahankan backend existing.
- Pisahkan service/data adapters dari UI state.
- Reuse endpoint dan permission existing.
- Jangan membuat fake production data.
- Capability yang belum ada harus unavailable, hidden, atau memakai fallback jujur.
- Buat asset slots agar hasil Brand workstream dapat diganti tanpa refactor besar.
- Buat component boundary agar hasil Learning System dapat masuk tanpa membongkar shell.

==================================================
UPLOAD UX TRANSLATION
==================================================

Saya menyukai UX pada screenshot, bukan UI visualnya.

Ambil pola berikut:

1. Drag feedback: dropzone langsung menjawab saat file valid/invalid memasuki area.
2. Honest progress: spinner saja tidak cukup; tampilkan real percent/bytes/stage, speed/ETA hanya bila reliable, serta guidance apakah tab harus tetap terbuka.
3. Inline retry: failure tinggal pada file yang gagal dan retry berada di row tersebut.
4. Upload preview: tampilkan filename, type, size, optional duration, source, validation, Replace, dan Remove.
5. Independent queue: setiap file memiliki lane/status sendiri; satu failure tidak menghapus atau mengulang file lain.
6. Safe completion: spinner berhenti dan success state menyebut file serta next action.

Jangan menyalin dark grid, neon teal/red, glow, card style, typography, atau English copy screenshot. Gunakan Light Editorial V4 semantic tokens.

Notara menerima audio/video sesuai repository. Jangan menambahkan image/PDF hanya karena screenshot menampilkannya.

==================================================
CHECKPOINT EXECUTION CONTRACT
==================================================

Jalankan hanya checkpoint yang diminta pengguna.

Pada awal checkpoint:

- sebutkan scope;
- sebutkan file yang diperkirakan berubah;
- sebutkan tests yang akan dijalankan;
- jangan mengerjakan checkpoint berikutnya.

Pada akhir checkpoint:

- ringkas perubahan;
- daftar file berubah;
- hasil lint/typecheck/test/build;
- screenshot atau QA evidence yang relevan;
- regression risks;
- unresolved questions;
- commit hash jika checkpoint mengizinkan commit;
- berhenti dan tunggu persetujuan.

==================================================
CHECKPOINT 0 — READ-ONLY AUDIT
==================================================

Jangan mengubah file atau membuat branch.

Audit minimal:

- `app/dashboard/page.tsx` dan component structure;
- auth/session boundaries;
- record/upload UI dan handlers;
- small-file multipart path;
- large-file decode/resample/chunk path;
- summarize-transcript path;
- folder/save path;
- current file count, MIME, size, and tier limits;
- current queue semantics;
- current error/retry behavior;
- current progress observability;
- browser-bound versus server-bound stages;
- tests, lint, typecheck, build, E2E availability;
- route/navigation activation strategy;
- deployment/runtime constraints.

Buat capability matrix:

| UX capability | Sudah ada | Frontend-only sekarang | Memerlukan backend baru | Fallback jujur |

Khusus upload UX, jawab:

- Bisakah direct upload memberikan real bytes progress tanpa server change?
- Bisakah chunk flow memberikan aggregate progress dan failed-chunk retry?
- Apakah multi-file current implementation sequential atau parallel?
- Berapa current max file count/size dan format?
- Apakah file tetap di memory setelah failure?
- Apakah user boleh pindah route/tab tanpa membatalkan proses?
- Kapan speed/ETA reliable?
- Tahap mana yang tidak memiliki percent?

Usulkan:

- component map;
- state model;
- service adapter map;
- safest feature activation;
- exact checkpoint file plan;
- regression test plan.

Berhenti tanpa perubahan repository.

==================================================
CHECKPOINT 1 — SAFETY BASELINE AND COMPONENT BOUNDARIES
==================================================

Setelah approval:

- pastikan working tree bersih;
- buat branch `feat/app-shell-v4-1-4-integration`;
- capture baseline tests;
- ekstrak component/service boundaries dari dashboard tanpa mengubah backend behavior;
- jangan redesign seluruh UI pada checkpoint ini;
- pertahankan flow existing byte-for-byte secara perilaku;
- tambahkan tests untuk critical existing paths bila memungkinkan.

==================================================
CHECKPOINT 2 — DESIGN SYSTEM AND APP SHELL
==================================================

Implementasikan:

- semantic Light/Dark/System tokens;
- light editorial shell;
- sidebar expanded/collapsed/mobile;
- utility topbar;
- route shell;
- focus management;
- responsive layout;
- `BrandMark`, `Wordmark`, `ProcessingMark` slots.

Jangan menunggu final brand assets. Gunakan swappable temporary component.

==================================================
CHECKPOINT 3 — HOME, COURSES, SHARED, NOTARA FOUNDATIONS
==================================================

Implementasikan canonical shell behaviors:

- returning/first-use Home;
- active/failed processing;
- Continue Learning;
- Courses;
- Shared filters/actions;
- Notara workspace foundation;
- Study Canvas/Learning Lab preview only.

Untuk `Belajar apa dulu?`:

- jangan membuat recommendation backend/AI baru;
- gunakan presentation boundary dan adapter;
- fallback paling konservatif boleh berdasarkan materi terakhir atau existing data;
- tandai logic sementara dalam implementation notes;
- mudah diganti setelah Learning System sync.

==================================================
CHECKPOINT 4 — CAPTURE UX STATE MODEL AND PRESENTATION
==================================================

Implementasikan frontend contract pada:

`docs/NOTARA_UPLOAD_FEEDBACK_AND_RECOVERY_UX_V1.md`

Wajib:

- drag valid/invalid feedback;
- real file input dan keyboard trigger;
- selected audio/video preview metadata;
- Replace/Remove;
- per-item task rows;
- queue summary;
- honest progress presentation;
- success terminal;
- inline failure/retry;
- accessible states;
- component/unit tests dengan fake adapter.

Jangan menyentuh backend pada checkpoint ini.

==================================================
CHECKPOINT 5 — WIRE EXISTING PIPELINE
==================================================

Hubungkan UI ke backend/client pipeline existing tanpa mengubah server contract.

Rules:

- direct upload: gunakan real progress event bila memungkinkan;
- evaluasi XHR hanya jika endpoint, cookies/auth, cancellation, and error semantics tetap sama dan tests lulus;
- chunk flow: gunakan aggregate bytes/chunk completion;
- decode/resample yang tidak measurable memakai stage copy;
- transcription/summary yang tidak measurable tidak memakai fake percent;
- ETA/speed hanya setelah sampel stabil;
- current count/size/MIME/tier limits tetap authoritative;
- current sequential queue tidak diubah menjadi parallel tanpa approval;
- retry per item/chunk hanya jika benar-benar didukung;
- jangan mengklaim resume setelah refresh;
- one failure tidak menghapus result item lain;
- copy leave/wait mengikuti capability audit;
- beforeunload hanya selama process yang benar-benar akan hilang.

Test minimal:

- small valid file;
- large/chunked file fixture;
- invalid MIME;
- over-size;
- multiple files sampai current limit;
- one item failure;
- retry;
- silent/AI error path;
- cancel/remove;
- success/save destination.

==================================================
CHECKPOINT 6 — RESPONSIVE, ACCESSIBILITY, REGRESSION QA
==================================================

Run repository-appropriate:

- lint;
- typecheck;
- unit/integration tests;
- production build;
- E2E/Playwright bila tersedia.

Viewport:

- 1440×1000;
- 1280×720;
- 1024×900;
- 390×844.

Audit:

- no horizontal overflow;
- Light/Dark/System;
- sidebar/drawer;
- Home/Courses/Shared/Notara;
- upload drag/preview/queue/progress/retry/success;
- recording;
- keyboard/focus/live region;
- reduced motion;
- auth/session;
- existing summary/chat/share/folder behavior;
- no blocking console errors.

==================================================
CHECKPOINT 7 — HANDOFF AND MERGE-READINESS
==================================================

Buat:

- implementation report;
- final QA report;
- screenshot index;
- changelog;
- remaining backend-dependent UX gaps;
- design/asset placeholders;
- Learning System integration hooks;
- rollback plan;
- merge recommendation.

Jangan merge, deploy, atau mengubah production configuration.

==================================================
STOP CONDITION
==================================================

Saat pengguna meminta `Jalankan Checkpoint N saja`, selesaikan hanya checkpoint tersebut dan berhenti.
```
