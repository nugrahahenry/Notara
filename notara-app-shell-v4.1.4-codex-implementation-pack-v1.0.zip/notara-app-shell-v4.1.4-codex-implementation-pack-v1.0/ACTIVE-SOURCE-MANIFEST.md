# Active Source Manifest — Codex Implementation

## Source precedence

| Domain | Source of truth |
|---|---|
| Runtime yang benar-benar ada | source code, route API, migrations, tests, dan konfigurasi repository aktif |
| Scope produk dan current behavior | PRD, FSD, API, Technical, dan Security documents di repository aktif |
| Target visual dan App Shell behavior | canonical handoff V4.1.4 di folder `canonical/` |
| Upload feedback, progress, preview, retry, dan queue | `docs/NOTARA_UPLOAD_FEEDBACK_AND_RECOVERY_UX_V1.md` |
| Screenshot UX | `references/upload-ux-patterns/` sebagai behavior-only references |
| Keputusan implementasi bertahap | `docs/BRANCH_AND_CHECKPOINT_PLAN.md` dan Prompt Master |

## Aturan konflik

- Source code menentukan apa yang saat ini didukung.
- Canonical handoff menentukan target UI/UX App Shell.
- Upload UX addendum boleh meningkatkan frontend behavior, tetapi tidak boleh mengarang backend capability.
- Bila target UX memerlukan backend baru, implementasikan fallback jujur dan catat sebagai follow-up; jangan membuat backend pada workstream ini.
- Learning System dan Brand/Asset workstream tidak boleh dihard-code sebelum hasilnya disinkronkan.

## Tidak aktif

- prototype V2/V3;
- App Shell V4.0–V4.1.3;
- dark-sidebar direction lama;
- old N-gradient logo;
- landing page redesign;
- Study Canvas/Formula/Speaker/Quiz implementation mendalam;
- backend resumable uploads, background jobs, WebSocket/SSE progress baru, database migrations, atau API baru.
