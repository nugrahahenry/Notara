# Upload UX Pattern References

These screenshots are behavior references only.

| File | Pattern |
|---|---|
| `UX-REF-01-SAFE-VS-BROKEN-COMPLETION.jpeg` | Terminal success must replace endless spinner |
| `UX-REF-02-HONEST-PROGRESS.jpeg` | Percent, time/rate when measurable, and leave/wait guidance |
| `UX-REF-03-DRAG-FEEDBACK.jpeg` | Immediate valid drag response |
| `UX-REF-04-UPLOAD-PREVIEW.jpeg` | Preview, metadata, Replace, Remove |
| `UX-REF-05-INLINE-RETRY.jpeg` | Local failure and retry without losing file context |
| `UX-REF-06-INDEPENDENT-QUEUE.jpeg` | Per-file lanes; one failure does not erase others |

Do not copy the dark grid, neon colors, typography, glow, layout, or English copy. Translate the patterns into Notara V4 Light Editorial design tokens and audio/video workflow.
